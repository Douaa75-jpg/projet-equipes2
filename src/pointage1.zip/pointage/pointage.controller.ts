import { Controller, Get, Post, Body, Param, Query } from '@nestjs/common';
import { PointageService } from './pointage.service';
import { ApiTags, ApiOperation, ApiResponse, ApiBody, ApiParam } from '@nestjs/swagger';

@ApiTags('pointages')
@Controller('pointages')
export class PointageController {
  constructor(private readonly pointageService: PointageService) {}

  @Post(':employeId')
  @ApiOperation({ summary: 'Enregistrer un pointage (entrée/sortie)' })
  @ApiParam({ name: 'employeId', description: 'ID de l\'employé' })
  @ApiResponse({ status: 201, description: 'Pointage enregistré avec succès' })
  async enregistrerPointage(@Param('employeId') employeId: string) {
    return this.pointageService.enregistrerPointage(employeId);
  }

  @Get('heures-travail/:employeId')
  @ApiOperation({ summary: 'Calculer les heures travaillées' })
  @ApiParam({ name: 'employeId', description: 'ID de l\'employé' })
  @ApiResponse({ status: 200, description: 'Heures travaillées calculées' })
  async calculerHeuresTravail(
    @Param('employeId') employeId: string,
    @Query('dateDebut') dateDebut: string,
    @Query('dateFin') dateFin: string,
  ) {
    return this.pointageService.calculerHeuresTravail(employeId, dateDebut, dateFin);
  }

  @Get('historique/:employeId')
  @ApiOperation({ summary: 'Obtenir l\'historique des pointages' })
  @ApiParam({ name: 'employeId', description: 'ID de l\'employé' })
  @ApiResponse({ status: 200, description: 'Historique des pointages' })
  async getHistorique(
    @Param('employeId') employeId: string,
    @Query('date') date: string,
  ) {
    return this.pointageService.getHistorique(employeId, date);
  }
}