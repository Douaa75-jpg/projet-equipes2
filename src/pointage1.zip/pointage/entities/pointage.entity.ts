export class Pointage {}
