import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { Pointage, PointageType } from '@prisma/client';
import moment from 'moment-timezone';

@Injectable()
export class PointageService {
  private readonly logger = new Logger(PointageService.name);
  private readonly timezone = 'Africa/Tunis'; // Fuseau horaire Tunisie (UTC+1)

  constructor(private prisma: PrismaService) {}

  async enregistrerPointage(employeId: string) {
    // 1. Capturer l'heure locale exacte
    const maintenantLocale = moment().tz(this.timezone);
    const heureLocaleFormattee = maintenantLocale.format('YYYY-MM-DD HH:mm:ss');
    
    // 2. Pour le stockage, utiliser l'heure locale SANS conversion UTC
    const aujourdhui = maintenantLocale.clone().startOf('day');
    
    // Logs de vérification
    this.logger.debug(`Heure Tunisie: ${heureLocaleFormattee}`);
    this.logger.debug(`Date stockée: ${aujourdhui.format('YYYY-MM-DD')}`);
  
    const dernierPointage = await this.prisma.pointage.findFirst({
      where: {
        employeId,
        date: {
          gte: aujourdhui.toDate(),
          lte: aujourdhui.clone().endOf('day').toDate()
        }
      },
      orderBy: { heure: 'desc' },
    });
  
    const type: PointageType = !dernierPointage || dernierPointage.type === 'SORTIE' 
      ? 'ENTREE' 
      : 'SORTIE';
  
    // Stockage DIRECT de l'heure locale
    await this.prisma.pointage.create({
      data: {
        employeId,
        date: aujourdhui.toDate(),
        heure: maintenantLocale.toDate(), // Stocke l'heure locale telle quelle
        type
      }
    });
  
    return { 
      message: `Pointage ${type === 'ENTREE' ? 'd\'arrivée' : 'de départ'} enregistré`,
      type,
      heureLocale: heureLocaleFormattee
    };
  }

  // Calculer les heures travaillées dans la journée

async calculerHeuresTravail(employeId: string, dateDebut: string, dateFin: string) {
  const debut = moment.tz(dateDebut, this.timezone).startOf('day');
    const fin = moment.tz(dateFin, this.timezone).endOf('day');

    const pointages = await this.prisma.pointage.findMany({
      where: {
        employeId,
        date: {
          gte: debut.toDate(),
          lte: fin.toDate()
        }
      },
      orderBy: { heure: 'asc' }
    });

    let totalHeures = 0;
    let entreePrecedente: Date | null = null;

    for (const pointage of pointages) {
      const heurePointage = moment(pointage.heure).tz(this.timezone);
      if (pointage.type === 'ENTREE') {
        entreePrecedente = heurePointage.toDate();
      } else if (pointage.type === 'SORTIE' && entreePrecedente) {
        const heureSortie = heurePointage;
        const dureeHeures = heureSortie.diff(moment(entreePrecedente).tz(this.timezone), 'hours', true);
        totalHeures += dureeHeures;
        entreePrecedente = null;
      }
    }

    return { 
      totalHeures,
      totalHeuresFormatted: `${Math.floor(totalHeures)}h ${Math.round((totalHeures % 1) * 60)}min`
    };
  }

  async getHistorique(employeId: string, date: string) {
    // Vérifier que l'employé existe
    const employeExiste = await this.prisma.employe.findUnique({
      where: { id: employeId }
    });
  
    if (!employeExiste) {
      throw new NotFoundException('Employé non trouvé');
    }
  
    // Traitement de la date avec le fuseau horaire
    const dateDebut = moment.tz(date, 'Africa/Tunis').startOf('day');
    const dateFin = dateDebut.clone().endOf('day');
  
    const pointages = await this.prisma.pointage.findMany({
      where: {
        employeId,
        date: {
          gte: dateDebut.toDate(),
          lte: dateFin.toDate()
        }
      },
      orderBy: { heure: 'asc' },
      select: {
        id: true,
        type: true,
        heure: true,
        date: true,
        employe: {
          select: {
            utilisateur: {
              select: {
                nom: true,
                prenom: true,
                matricule: true
              }
            }
          }
        }
      }
    });
  
    // Conversion des heures en format local Tunis
    return pointages.map(p => ({
      id: p.id,
      type: p.type,
      typeLibelle: p.type === 'ENTREE' ? 'Arrivée' : 'Départ',
      date: moment(p.date).tz('Africa/Tunis').format('YYYY-MM-DD'),
      heure: moment(p.heure).tz('Africa/Tunis').format('HH:mm:ss'),
      employe: {
        nom: p.employe.utilisateur.nom,
        prenom: p.employe.utilisateur.prenom,
        matricule: p.employe.utilisateur.matricule
      }
    }));
  }
}